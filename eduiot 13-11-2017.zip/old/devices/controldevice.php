<?php
// Include config file
require_once 'config.php';
 






require_once 'config.php';
$snm = "12345678";
$snm2 = "d2";


$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2){
                
        //echo "id: " . $row["id"]. " - Devicename: " . $row["devicename"].  " - Username: " . $row["username"].  " - Key: " . $row["ekey"].  " - Command: " . $row["command"].  " </br> ";
        //$uid = $row["id"];
        //$ucmd =  $row["command"];
        //echo  $ucmd;
        }
        }
    }
} else {
    echo "0 results";
}




?>

<?php
    // if post with name is posted, set value to 1, else to 0
    for ($x = 0; $x <= 1; $x++) {
    $a[$x]= isset($_POST['check'][$x]) ? "a": "b";
    //echo   $a[$x];
    }

    //$a[4]=isset($_POST['check'][4]) ? $_POST['check'][4]: 0;
   // echo   $a[4];
  //  echo  "<br>";
$all= $a[0]; //.$a[1].$a[2].$a[3]."s". $a[4];
//echo $all;

    
for ($x = 0; $x <= 1; $x++) {
if ($a[$x]=="a"){
    $c[$x]= "checked";
    //echo   $c[$x];
    }
    else
    $c[$x]= "";
}

//$c[4]=$a[4];
// Include config file
//require_once 'config.php';

//$snm = "12345678";
//$snm2 = "d2";
$snm3 = $all;

//echo $_POST['c[0]'];
//echo  $snm3 ;




$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2){
                
        //echo "id: " . $row["id"]. " - Devicename: " . $row["devicename"].  " - Username: " . $row["username"].  " - Key: " . $row["ekey"].  " - Command: " . $row["command"].  " </br> ";
        $uid = $row["id"];
        //$ucmd =  $row["command"];
        //echo  $ucmd;
        }
        }
    }
} else {
    echo "0 results";
}




$sq1 = "UPDATE devices SET command='$snm3' WHERE id=$uid";

if ($link->query($sq1) === TRUE) {
      
   ;// echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}




$link->close();

?>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Introducing Lollipop, a sweet new take on Android.">
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Eduiot | IOT solution </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">

    <!-- Page styles -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-lite/1.3.0/material.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
    #view-source {
      position: fixed;
      display: block;
      right: 0;
      bottom: 0;
      margin-right: 40px;
      margin-bottom: 40px;
      z-index: 900;
    }
    </style>
        <style type="text/css">
        body{ font: 14px sans-serif;  }
        .wrapper{ width: 350px; padding: 20px; margin: auto ;}
    </style>

        <link rel="stylesheet" type="text/css" href="button.css" />
        <style>
body{  
    background: #2A3D4F;
    color: #FFF;
    text-align: center;   
  }
h1{
    font-family: Roboto, sans-serif; 
  font-size: 35px; 
  font-weight: 300; 
}
button {
    width: 30%;
    background-color: #4CAF50;
    color: white;
    padding: 10px 10px;
    margin: 8px 0;
  font-size: 25px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
input[type=text], select {
    width: 60%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
p{
    font-size: 25px;
}
 div.demo{text-align: center; width: 280px; float: left}
 div.demo > p{font-size: 20px}
</style>

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
     <script src="jquery.min.js"></script>
    <script src="jquery.knob.min.js"></script>
    <script>
            $(function($) {

                $(".knob").knob({
                    change : function (value) {
                        //console.log("change : " + value);
                     

                    },
                    release : function (value) {
                        //console.log(this.$.attr('value'));
                        console.log("release : " + value);
                         updatefrom();
                    },
                    cancel : function () {
                        console.log("cancel : ", this);
                    },
                    /*format : function (value) {
                        return value + '%';
                    },*/
                    draw : function () {

                        // "tron" case
                        if(this.$.data('skin') == 'tron') {

                            this.cursorExt = 0.3;

                            var a = this.arc(this.cv)  // Arc
                                , pa                   // Previous arc
                                , r = 1;

                            this.g.lineWidth = this.lineWidth;

                            if (this.o.displayPrevious) {
                                pa = this.arc(this.v);
                                this.g.beginPath();
                                this.g.strokeStyle = this.pColor;
                                this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, pa.s, pa.e, pa.d);
                                this.g.stroke();
                            }

                            this.g.beginPath();
                            this.g.strokeStyle = r ? this.o.fgColor : this.fgColor ;
                            this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d);
                            this.g.stroke();

                            this.g.lineWidth = 2;
                            this.g.beginPath();
                            this.g.strokeStyle = this.o.fgColor;
                            this.g.arc( this.xy, this.xy, this.radius - this.lineWidth + 1 + this.lineWidth * 2 / 3, 0, 2 * Math.PI, false);
                            this.g.stroke();

                            return false;
                        }
                    }
                });

                // Example of infinite knob, iPod click wheel
               
            });
        </script>
 <script>$(document).ready(function(){    
    loadstation();
});

function loadstation(){
    $("#station_data").load("view.php");
    setTimeout(loadstation, 2000);
}
</script>
	
    </head>
    <body>


  <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">

      <div class="android-header mdl-layout__header mdl-layout__header--waterfall">
        <div class="mdl-layout__header-row">
          <span class="android-title mdl-layout-title">
            <img class="android-logo-image" src="images/eduiotc.png">
          </span>
          <!-- Add spacer, to align navigation to the right in desktop -->
          <div class="android-header-spacer mdl-layout-spacer"></div>
          <div class="android-search-box mdl-textfield mdl-js-textfield mdl-textfield--expandable mdl-textfield--floating-label mdl-textfield--align-right mdl-textfield--full-width">
            
         
          </div>
          <!-- Navigation -->
        
          <span class="android-mobile-title mdl-layout-title">
            <img class="android-logo-image-mobile" src="images/eduiotc.png">
          </span>
          <button class="android-more-button mdl-button mdl-js-button mdl-button--icon mdl-js-ripple-effect" id="more-button">
            <i class="material-icons">more_vert</i>
          </button>
          <ul class="mdl-menu mdl-js-menu mdl-menu--bottom-right mdl-js-ripple-effect" for="more-button">
            <li ><a class="mdl-menu__item" href="settings.php" >Settings</a></li>
            <li ><a class="mdl-menu__item" href="logout.php" >Sign Out</a></li>
          </ul>
        </div>
      </div>

      <div class="android-drawer mdl-layout__drawer" class="scrollbar" id="style-3">
        <span style="text-align: left;"class="mdl-layout-title">
          <img class="android-logo-image" src="images/eduiotw.png">
        </span>
        <nav class="mdl-navigation">
          <a class="mdl-navigation__link" href="account.php">Account</a>
          <a class="mdl-navigation__link" href="dashboard.php" >My Devices</a>
          <a class="mdl-navigation__link" href="adddevice.php" >Add Device</a>
          <a class="mdl-navigation__link" href="updatedevice.php" >Update Device</a>
          <a class="mdl-navigation__link" href="logout.php">Sign Out</a>
      
        </nav>
      </div>














      <div class="android-content mdl-layout__content" >
        <a name="top"></a>



 <!--   <div id="station_data"></div>   -->

   


<form id="cform" method="post">
                
                <div class="switch demo3">
					<input type = 'checkbox' name = 'check[0]' value = '1' onchange = "updatefrom()" <?php  echo $c[0]?>> 
					<label><i></i></label>
				</div>

        
</form>


<script>
function updatefrom(){
    document.getElementById("cform").submit();
}
</script>


  <div >
            <h2 class="copyright">© 2017 eduiot Technologies</h2>
  </div>
       

        
      </div>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/material-design-lite/1.3.0/material.min.js"></script>


  </body>
</html>




