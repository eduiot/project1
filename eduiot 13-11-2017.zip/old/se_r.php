<?php


// Include config file
require_once 'config.php';
 


// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}

$snm = "12345678";
$snm2 = "d2";

 

$sql = "SELECT id, devicename, username, ekey, command, udate FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2){
        echo  $row["command"];
        echo  "<br>";
        echo  $row["udate"];
            }
        }
    }
} else {
    echo "0 results";
}

$link->close();
?>
